custom command prog id
SP3DCmds.PlaceRRings

Select Runs to Place Stiffeners, 
start the command, and 
then provide inputs on the ribbon bar
(spacing and Stiffener Ring Specialty Tag)