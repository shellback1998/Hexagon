Attached are the four files required to create the sample WBS label.  Just create a new folder in your symbol share and drop them in:
 
...\Labels\Types of Labels\Piping\WBS Label\  (verify correct spelling, an incorrect path will result in errors)
 
Once this is done, bulkolad the "Reports_WBS_Label.xls" spreadsheet that is attached; it is ready to load using Add/Modify/Delete option.
You can then run SP3D and the WBS command and you should be able to navigate to this label.
